package main;

import java.util.Scanner;
import piezas.Pieza;
import piezas.Rey;

/**
 * Controlador principal del flujo del juego.
 */
public class Juego {
    private final Tablero tablero;
    private final Jugador j1;
    private final Jugador j2;
    private Jugador actual;

    public Juego() {
        this.tablero = new Tablero();
        this.j1 = new Jugador("Blanco", true);
        this.j2 = new Jugador("Negro", false);
        this.actual = j1;
    }

    public void jugar() {
        Scanner lector = new Scanner(System.in);
        boolean partidaActiva = true;

        System.out.println("=== AJEDREZ PROFESIONAL JAVA ===");

        while (partidaActiva) {
            tablero.mostrarTablero();
            System.out.println("\nTurno de: " + actual.getNombre() + " (" + (actual.isBlanco() ? "B" : "N") + ")");

            try {
                System.out.print("Fila Origen: ");
                int fO = lector.nextInt();
                System.out.print("Columna Origen: ");
                int cO = lector.nextInt();
                System.out.print("Fila Destino: ");
                int fD = lector.nextInt();
                System.out.print("Columna Destino: ");
                int cD = lector.nextInt();

                // Intentar realizar el movimiento
                Pieza resultado = tablero.moverPieza(fO, cO, fD, cD, actual.isBlanco());

                if (resultado != null) {
                    System.out.println(">> Movimiento confirmado.");

                    // Si se capturó una pieza real (no el dummy del movimiento a vacío)
                    if (resultado.getFila() != -1) {
                        actual.capturarPieza();
                        if (resultado instanceof Rey) {
                            System.out.println("\n¡JAQUE MATE! El jugador " + actual.getNombre() + " ha ganado.");
                            partidaActiva = false;
                        }
                    }

                    // Cambiar turno
                    if (partidaActiva) actual = (actual == j1) ? j2 : j1;

                } else {
                    System.out.println("!! Error: Movimiento ilegal o casilla vacía.");
                }

            } catch (Exception e) {
                System.out.println("!! Error: Entrada no válida. Use números del 0 al 7.");
                lector.nextLine(); // Limpiar buffer
            }
        }

        System.out.println("\n--- Resumen de la Partida ---");
        j1.mostrarInfo();
        j2.mostrarInfo();
        lector.close();
    }

    public static void main(String[] args) {
        new Juego().jugar();
    }
}