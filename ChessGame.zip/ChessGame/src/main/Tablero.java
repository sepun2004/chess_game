package main;

import piezas.*;

/**
 * Gestiona el estado del tablero de ajedrez de 8x8.
 * Implementa la lógica de disposición inicial y validación de movimientos.
 */
public class Tablero {
    private static final int TAMANO = 8;
    private final Pieza[][] casillas;

    public Tablero() {
        this.casillas = new Pieza[TAMANO][TAMANO];
        inicializarTablero();
    }

    private void inicializarTablero() {
        // Piezas Negras
        colocarPiezasMayores(0, false);
        for (int j = 0; j < TAMANO; j++) {
            casillas[1][j] = new Peon(1, j, false);
        }

        // Piezas Blancas
        colocarPiezasMayores(7, true);
        for (int j = 0; j < TAMANO; j++) {
            casillas[6][j] = new Peon(6, j, true);
        }
    }

    private void colocarPiezasMayores(int fila, boolean esBlanca) {
        casillas[fila][0] = new Torre(fila, 0, esBlanca);
        casillas[fila][1] = new Caballo(fila, 1, esBlanca);
        casillas[fila][2] = new Alfil(fila, 2, esBlanca);
        casillas[fila][3] = new Reina(fila, 3, esBlanca);
        casillas[fila][4] = new Rey(fila, 4, esBlanca);
        casillas[fila][5] = new Alfil(fila, 5, esBlanca);
        casillas[fila][6] = new Caballo(fila, 6, esBlanca);
        casillas[fila][7] = new Torre(fila, 7, esBlanca);
    }

    /**
     * Mueve una pieza y gestiona la captura.
     * @return La pieza capturada si la hubo, null si no hubo captura o el movimiento falló.
     * @throws IllegalArgumentException Si el movimiento es ilegal.
     */
    public Pieza moverPieza(int fO, int cO, int fD, int cD, boolean esBlanco) {
        if (!esPosicionValida(fO, cO) || !esPosicionValida(fD, cD)) return null;

        Pieza p = casillas[fO][cO];
        if (p == null || p.isEsBlanca() != esBlanco) return null;

        if (p.esMovimientoValido(fD, cD, casillas)) {
            Pieza capturada = casillas[fD][cD];

            // Ejecutar el movimiento
            casillas[fD][cD] = p;
            casillas[fO][cO] = null;
            p.mover(fD, cD);

            // Retornamos la pieza capturada (o una pieza "dummy" si el destino era null
            // pero el movimiento fue exitoso) para que Juego sepa que el movimiento fue válido.
            return (capturada == null) ? new Peon(-1, -1, !esBlanco) : capturada;
        }
        return null;
    }

    public boolean esPosicionValida(int f, int c) {
        return f >= 0 && f < TAMANO && c >= 0 && c < TAMANO;
    }

    public void mostrarTablero() {
        System.out.println("\n    0  1  2  3  4  5  6  7");
        System.out.println("  -------------------------");
        for (int i = 0; i < TAMANO; i++) {
            System.out.print(i + " |");
            for (int j = 0; j < TAMANO; j++) {
                System.out.print(casillas[i][j] == null ? " . " : casillas[i][j].getSimbolo());
            }
            System.out.println("|");
        }
        System.out.println("  -------------------------");
    }
}
